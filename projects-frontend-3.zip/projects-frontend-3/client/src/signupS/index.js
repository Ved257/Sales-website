import SignUpS from "./SignUpS";

export default SignUpS