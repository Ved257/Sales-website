import Landing from "./Landing";


export default Landing