import ThankYouS from './ThankYouS'

export default ThankYouS