import QR_generator from "./QR_generator";


export default QR_generator